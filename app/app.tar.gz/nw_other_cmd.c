#include "utils.h"
#include "nw_cli.h"
#include "manage.h"



//nw_show_
int nw_other_show(int argc,char **argv)
{
    return 0;
}